/**
  * Created by Administrator on 2016-07-22.
  */
class qazxswe {
  def main(args: Array[String]): Unit = {
    println("asd")
  }
}
